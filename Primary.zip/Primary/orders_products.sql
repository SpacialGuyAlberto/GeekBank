INSERT INTO public.orders_products (orders_id, products_id) VALUES (1, 1);
INSERT INTO public.orders_products (orders_id, products_id) VALUES (2, 2);
INSERT INTO public.orders_products (orders_id, products_id) VALUES (3, 16);
INSERT INTO public.orders_products (orders_id, products_id) VALUES (4, 22);
INSERT INTO public.orders_products (orders_id, products_id) VALUES (5, 24);
INSERT INTO public.orders_products (orders_id, products_id) VALUES (6, 25);
