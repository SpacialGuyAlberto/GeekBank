INSERT INTO public.combo_products (combo_id, product_id) VALUES (1, 83405);
INSERT INTO public.combo_products (combo_id, product_id) VALUES (1, 93618);
