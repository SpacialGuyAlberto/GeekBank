INSERT INTO public.transaction_products (id, product_id, quantity, transaction_id) VALUES (1, 83405, 1, 1);
INSERT INTO public.transaction_products (id, product_id, quantity, transaction_id) VALUES (2, 83405, 1, 2);
INSERT INTO public.transaction_products (id, product_id, quantity, transaction_id) VALUES (16, 83405, 1, 16);
INSERT INTO public.transaction_products (id, product_id, quantity, transaction_id) VALUES (22, 83405, 1, 22);
INSERT INTO public.transaction_products (id, product_id, quantity, transaction_id) VALUES (24, 83405, 1, 24);
INSERT INTO public.transaction_products (id, product_id, quantity, transaction_id) VALUES (25, 233018, 1, 25);
