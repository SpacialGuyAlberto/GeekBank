INSERT INTO public.cart_item (id, price, product_id, quantity, user_id) VALUES (14, 0, 14340, 1, 1);
