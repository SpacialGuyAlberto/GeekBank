INSERT INTO public.promotion (id, code, discount_porcentage, user_id) VALUES (1, 'WELCOME10', 10, 1);
