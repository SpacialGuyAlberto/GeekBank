INSERT INTO public.activation_details (id, kinguin_id, text_details, video_url) VALUES (1, 83405, e'Acceda a su cuenta en https://pagostore.garena.com/?channel=250000. 
Acceda a la página «Recarga de saldo de Free Fire Mobile» e introduzca su ID de jugador de Free Fire. 
Accede a la página «Canjear código» e introduce tu código de canje. 
Podrás canjear el valor de este código por Diamantes Free Fire.', '');
