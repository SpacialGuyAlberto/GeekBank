INSERT INTO public.tournaments (id, description, end_date, name, start_date, status, moderator_id) VALUES (1, 'Description', '2025-06-11', 'Tournament', '2025-06-04', 'ACTIVE', 2);
